ExamMaker — تطبيق أندرويد (WebView)
كل عمليات البناء تتم على GitHub Actions من تبويب Actions:
  debug    = ملف APK للتجربة (يعمل تلقائيًا عند كل رفع)
  keystore = إنشاء مفتاح التوقيع (مرة واحدة فقط)
  release  = ملف AAB موقّع للنشر في Google Play
الواجهة: app/src/main/assets/index.html
