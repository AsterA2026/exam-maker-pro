#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p out
TASK="${TASK:-debug}"

case "$TASK" in
  debug)
    python3 ci/bundle.py
    gradle assembleDebug
    cp app/build/outputs/apk/debug/app-debug.apk out/ExamMaker-debug.apk
    ;;
  keystore)
    bash ci/keystore.sh
    ;;
  release)
    : "${KEYSTORE_BASE64:?السر KEYSTORE_BASE64 غير موجود}"
    : "${KEYSTORE_PASSWORD:?السر KEYSTORE_PASSWORD غير موجود}"
    : "${KEY_ALIAS:?السر KEY_ALIAS غير موجود}"
    python3 ci/bundle.py
    echo "$KEYSTORE_BASE64" | base64 -d > "$PWD/release.jks"
    export KEYSTORE_PATH="$PWD/release.jks"
    gradle bundleRelease assembleRelease
    cp app/build/outputs/bundle/release/app-release.aab out/ExamMaker-release.aab
    cp app/build/outputs/apk/release/app-release.apk out/ExamMaker-release.apk
    rm -f release.jks
    ;;
  *) echo "unknown task: $TASK"; exit 1 ;;
esac
ls -la out
