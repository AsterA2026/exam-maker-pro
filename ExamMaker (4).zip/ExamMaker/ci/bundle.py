"""يضمّن الخطوط والمكتبات داخل التطبيق ليعمل دون إنترنت. يفشل البناء إن تعذّر التنزيل."""
import re, os, hashlib, urllib.request

ASSETS = 'app/src/main/assets'
UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36'

def get(u):
    return urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': UA}), timeout=60).read()

os.chdir(ASSETS)
html = open('index.html', encoding='utf8').read()

# 1) الخطوط
m = re.search(r'<link href="(https://fonts\.googleapis\.com/css2[^"]+)" rel="stylesheet">', html)
assert m, 'fonts link not found'
css = get(m.group(1)).decode()
os.makedirs('fonts', exist_ok=True)
out = []
for sub, block in re.findall(r'/\* ([\w-]+) \*/\s*(@font-face \{.*?\})', css, re.S):
    if sub not in ('arabic', 'latin'):
        continue
    u = re.search(r'url\((https://[^)]+)\)', block).group(1)
    fn = hashlib.md5(u.encode()).hexdigest()[:12] + '.woff2'
    if not os.path.exists('fonts/' + fn):
        open('fonts/' + fn, 'wb').write(get(u))
    out.append(block.replace(u, fn))
assert out, 'no fonts found'
open('fonts/fonts.css', 'w', encoding='utf8').write('\n'.join(out))
html = html.replace(m.group(0), '<link href="fonts/fonts.css" rel="stylesheet">')
print('fonts bundled:', len(out))

# 2) المكتبات (html2canvas, jsPDF, JSZip)
os.makedirs('libs', exist_ok=True)
libs = re.findall(r'<script src="(https://cdnjs\.cloudflare\.com/[^"]+)">', html)
assert len(libs) == 3, libs
for u in libs:
    name = u.rsplit('/', 1)[1]
    data = get(u)
    assert len(data) > 10000, name
    open('libs/' + name, 'wb').write(data)
    html = html.replace('<script src="%s">' % u, '<script src="libs/%s">' % name)
print('libs bundled:', len(libs))

open('index.html', 'w', encoding='utf8').write(html)
