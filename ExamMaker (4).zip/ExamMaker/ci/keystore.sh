#!/usr/bin/env bash
# ينشئ مفتاح رفع (upload key) مرة واحدة، ويعرض القيم في ملخص التشغيل لنسخها إلى GitHub Secrets
set -euo pipefail
mkdir -p out
PASS=$(openssl rand -base64 32 | tr -dc 'A-Za-z0-9' | head -c 24)
keytool -genkeypair -keystore out/upload-keystore.jks -alias upload \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=Exam Maker"
{
  echo "## قيم المفتاح — انسخ كل قيمة إلى Secret بالاسم المذكور"
  echo "### KEYSTORE_PASSWORD"; echo '```'; echo "$PASS"; echo '```'
  echo "### KEY_ALIAS"; echo '```'; echo "upload"; echo '```'
  echo "### KEYSTORE_BASE64"; echo '```'; base64 -w0 out/upload-keystore.jks; echo; echo '```'
} >> "${GITHUB_STEP_SUMMARY:-/dev/stdout}"
