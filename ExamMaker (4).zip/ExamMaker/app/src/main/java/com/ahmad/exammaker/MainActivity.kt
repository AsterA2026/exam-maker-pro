package com.ahmad.exammaker

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.*
import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var root: LinearLayout
    private lateinit var topBar: View
    private var filePathCb: ValueCallback<Array<Uri>>? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        filePathCb = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        web = WebView(this)
        topBar = View(this).apply { setBackgroundColor(0xFF0F6B5C.toInt()) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
            addView(topBar, LinearLayout.LayoutParams(-1, 0))
            addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        setContentView(root)
        WindowCompat.getInsetsController(window, root).isAppearanceLightStatusBars = false
        // أندرويد 15+ يرسم التطبيق خلف شريط الحالة: نترك مساحة للأشرطة وللوحة المفاتيح
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            topBar.layoutParams = topBar.layoutParams.apply { height = bars.top }
            v.setPadding(bars.left, 0, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true   // localStorage: حفظ الامتحانات داخل التطبيق
            allowFileAccess = false
            allowContentAccess = false
        }
        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, req: WebResourceRequest) =
                loader.shouldInterceptRequest(req.url)

            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                if (req.url.host == "appassets.androidplatform.net") return false
                startActivity(Intent(Intent.ACTION_VIEW, req.url)); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                filePathCb?.onReceiveValue(null); filePathCb = cb
                return try { picker.launch(p.createIntent()); true } catch (e: Exception) { filePathCb = null; false }
            }
        }

        // زر الرجوع: يغلق النافذة المفتوحة أو المعاينة أولًا ثم يخرج
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript(
                    "(function(){var s=document.querySelector('#sheet.on');if(s){closeSheet();return 1}" +
                    "if(document.body.dataset.p==='1'){document.querySelector('#nav [data-act=tab]').click();return 1}return 0})()"
                ) {
                    if (it != "1") finish()
                }
            }
        })

        if (savedInstanceState == null) web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); web.saveState(out) }

    private fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }

    private fun saveToDownloads(name: String, mime: String, bytes: ByteArray) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ExamMaker")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            toast("تم الحفظ في التنزيلات/ExamMaker")
        } catch (e: Exception) { toast("تعذر الحفظ: ${e.message}") }
    }

    inner class Bridge {
        /** معرّف الجهاز لربط كود الاشتراك بجهاز واحد */
        @JavascriptInterface fun deviceId(): String =
            Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        /** يلوّن شريط الحالة العلوي والسفلي ليطابق ألوان التطبيق */
        @JavascriptInterface fun setBar(top: String, bottom: String) { runOnUiThread {
            try { topBar.setBackgroundColor(Color.parseColor(top)); root.setBackgroundColor(Color.parseColor(bottom)) } catch (e: Exception) {}
        } }
        /** طباعة الورقة (ومنها «حفظ كـ PDF» من نافذة الطباعة) */
        @JavascriptInterface fun print() { runOnUiThread {
            val pm = getSystemService(PRINT_SERVICE) as PrintManager
            pm.print("exam", web.createPrintDocumentAdapter("exam"),
                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
        } }
        /** ملف Word (HTML بامتداد doc) */
        @JavascriptInterface fun saveDoc(html: String) =
            saveToDownloads("exam_${System.currentTimeMillis()}.doc", "application/msword",
                ("\uFEFF" + html).toByteArray(Charsets.UTF_8))
        /** أي ملف آخر، مثل النسخة الاحتياطية JSON */
        @JavascriptInterface fun saveFile(name: String, mime: String, b64: String) =
            saveToDownloads(name, mime, Base64.decode(b64, Base64.DEFAULT))
    }
}
